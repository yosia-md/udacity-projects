import torch
import torch.nn as nn
import torch.optim as optim
import json
import os
import matplotlib.pyplot as plt
from torchvision import models, transforms, datasets
from torch.utils.data import DataLoader
from argparse import ArgumentParser

# Argument parser to allow hyperparameter settings
parser = ArgumentParser(description="Train a model on image data.")
parser.add_argument('--data_dir', type=str, default='/workspace/cd0673/43ef1733-cf74-40a9-8c22-b6e440128200/image-classifier-part-1-workspace/home/aipnd-project/flowers', help='Directory containing the data.')
parser.add_argument('--arch', type=str, default='vgg16', choices=['vgg16', 'resnet'], help='Model architecture to use.')
parser.add_argument('--learning_rate', type=float, default=0.0001, help='Learning rate for the optimizer.')
parser.add_argument('--hidden_units', type=int, default=512, help='Number of hidden units in the classifier.')
parser.add_argument('--epochs', type=int, default=5, help='Number of epochs to train.')
parser.add_argument('--gpu', action='store_true', help='Use GPU for training.')
args = parser.parse_args()

# Directories for data
train_dir = os.path.join(args.data_dir, 'train')
valid_dir = os.path.join(args.data_dir, 'valid')
test_dir = os.path.join(args.data_dir, 'test')

# Define your transforms for the training, validation, and testing sets
data_transforms = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'val': transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'test': transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
}

# Load the datasets with ImageFolder
image_datasets = {
    'train': datasets.ImageFolder(root=train_dir, transform=data_transforms['train']),
    'val': datasets.ImageFolder(root=valid_dir, transform=data_transforms['val']),
    'test': datasets.ImageFolder(root=test_dir, transform=data_transforms['test'])
}

# Define the dataloaders
batch_size = 32
dataloaders = {
    'train': DataLoader(image_datasets['train'], batch_size=batch_size, shuffle=True, num_workers=4),
    'val': DataLoader(image_datasets['val'], batch_size=batch_size, shuffle=True, num_workers=4),
    'test': DataLoader(image_datasets['test'], batch_size=batch_size, shuffle=True, num_workers=4)
}

# Load category names
with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)

# Select model architecture
if args.arch == 'vgg16':
    model = models.vgg16(pretrained=True)
else:
    model = models.resnet50(pretrained=True)

# Freeze parameters
for param in model.parameters():
    param.requires_grad = False

# Modify the classifier
num_classes = 102  # Adjust based on your dataset
if args.arch == 'vgg16':
    model.classifier = nn.Sequential(
        nn.Linear(25088, args.hidden_units),
        nn.ReLU(),
        nn.Dropout(0.4),
        nn.Linear(args.hidden_units, num_classes),
        nn.LogSoftmax(dim=1)
    )
else:  # ResNet architecture
    model.fc = nn.Sequential(
        nn.Linear(model.fc.in_features, args.hidden_units),
        nn.ReLU(),
        nn.Dropout(0.4),
        nn.Linear(args.hidden_units, num_classes),
        nn.LogSoftmax(dim=1)
    )

device = torch.device("cuda" if (args.gpu and torch.cuda.is_available()) else "cpu")
model = model.to(device)

criterion = nn.NLLLoss()
optimizer = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.learning_rate)

def train_model(model, dataloaders, criterion, optimizer, num_epochs):
    for epoch in range(num_epochs):
        print(f"Epoch {epoch + 1}/{num_epochs}")
        print('-' * 20)

        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

            run_loss = 0.0
            run_corrects = 0

            for inputs, labels in dataloaders[phase]:
                inputs, labels = inputs.to(device), labels.to(device)

                optimizer.zero_grad()  # Zero the parameter gradients

                # Forward pass
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)
                    _, preds = torch.max(outputs, 1)

                    # Backward pass + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                run_loss += loss.item() * inputs.size(0)
                run_corrects += torch.sum(preds == labels.data)

            epoch_loss = run_loss / len(image_datasets[phase])
            epoch_acc = run_corrects.double() / len(image_datasets[phase])

            print(f"{phase} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}")

    return model

# Train the model
model = train_model(model, dataloaders, criterion, optimizer, args.epochs)

# Evaluate the model
def evaluate_model(model, dataloaders):
    model.eval()  # Set model to evaluate mode
    running_corrects = 0

    with torch.no_grad():
        for inputs, labels in dataloaders['test']:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)
            running_corrects += torch.sum(preds == labels.data)

    test_acc = running_corrects.double() / len(image_datasets['test'])
    print(f'Test Accuracy: {test_acc:.4f}')

# Evaluate the model
evaluate_model(model, dataloaders)

# TODO: Do validation on the test set

model.eval()
test_loss = 0
test_acc = 0
with torch.no_grad():
    for inputs,labels in dataloaders['test']:
        inputs,labels = inputs.to(device),labels.to(device)
        logps = model(inputs)
        test_loss += criterion(logps,labels).item()
        ps = torch.exp(logps)
        top_p,top_class = ps.topk(1,dim=1)
        equals = top_class == labels.view(*top_class.shape)
        test_acc += torch.mean(equals.type(torch.FloatTensor)).item()
    
print(f"valid loss on test data: {test_loss/len(dataloaders['test']):.3f}.. "
      f"valid accuracy on test data: {test_acc/len(dataloaders['test']):.3f}")

# Save the checkpoint
model.class_to_idx = image_datasets['train'].class_to_idx
checkpoint = {
    'model_state_dict': model.state_dict(),
    'optimizer_state_dict': optimizer.state_dict(),
    'class_to_idx': model.class_to_idx
}
torch.save(checkpoint, 'flower_classifier_checkpoint.pth')
