import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from PIL import Image
import numpy as np
import json
import matplotlib.pyplot as plt
import argparse

def load_checkpoint(checkpoint_path, arch, hidden_units):
    if arch == 'vgg16':
        model = models.vgg16(pretrained=True)
    else:
        model = models.resnet50(pretrained=True)

    checkpoint = torch.load(checkpoint_path) 

    # Freeze parameters
    for param in model.parameters():
        param.requires_grad = False

    num_classes = 102  # Adjust based on your dataset
    if arch == 'vgg16':
        model.classifier = nn.Sequential(
            nn.Linear(25088, hidden_units),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(hidden_units, num_classes),
            nn.LogSoftmax(dim=1)
        )
    else:  # ResNet architecture
        model.fc = nn.Sequential(
            nn.Linear(model.fc.in_features, hidden_units),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(hidden_units, num_classes),
            nn.LogSoftmax(dim=1)
        )

    # Load the saved state dictionaries
    model.load_state_dict(checkpoint['model_state_dict'])
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    print('Model and checkpoint loaded successfully.')
    return model

def preprocess_image(image_path):
    pil_image = Image.open(image_path)
    pil_image.thumbnail((256, 256), Image.LANCZOS) 

    width, height = pil_image.size
    new_width, new_height = 224, 224
    
    left = (width - new_width) / 2
    top = (height - new_height) / 2
    right = (width + new_width) / 2
    bottom = (height + new_height) / 2
    
    pil_image = pil_image.crop((left, top, right, bottom))

    np_image = np.array(pil_image, dtype=np.float32) / 255.0 

    means = np.array([0.485, 0.456, 0.406], dtype=np.float32)
    stds = np.array([0.229, 0.224, 0.225], dtype=np.float32)
    
    np_image = (np_image - means) / stds
    np_image = np_image.transpose((2, 0, 1))

    tensor_image = torch.from_numpy(np_image)

    return tensor_image

def predict(image_path, model, top_k=5):
    model.eval()
    
    image_tensor = preprocess_image(image_path)
    image_tensor = image_tensor.unsqueeze(0)

    device = next(model.parameters()).device  
    image_tensor = image_tensor.to(device) 

    with torch.no_grad():
        output = model(image_tensor)

    probs = F.softmax(output, dim=1)

    top_probs, indices = torch.topk(probs, top_k)

    top_probs = top_probs.cpu().numpy()[0]
    indices = indices.cpu().numpy()[0]

    class_to_idx = model.class_to_idx
    idx_to_class = {v: k for k, v in class_to_idx.items()}
    
    classes = [idx_to_class[idx] for idx in indices]

    return top_probs, classes

def load_cat_to_name(file_path):
    with open(file_path, 'r') as f:
        cat_to_name = json.load(f)
    return cat_to_name

def display_prediction(image_path, model, cat_to_name, top_k=5):
    image_tensor = preprocess_image(image_path)
    
    device = next(model.parameters()).device  
    image_tensor = image_tensor.to(device)  
    
    model.eval()
    with torch.no_grad():
        logits = model(image_tensor.unsqueeze(0))
        probabilities = torch.softmax(logits, dim=1)

    probabilities = probabilities.detach().cpu().numpy().squeeze()
    top_probs, top_indices = torch.topk(torch.tensor(probabilities), top_k)
    top_classes = [cat_to_name[str(index.item())] for index in top_indices]

    plt.figure(figsize=(10, 6))
    ax1 = plt.subplot(1, 2, 1)
    ax1.imshow(image_tensor.cpu().numpy().transpose((1, 2, 0)))
    ax1.axis('off')
    
    ax2 = plt.subplot(1, 2, 2)
    ax2.barh(top_classes, top_probs.cpu().numpy())
    ax2.set_xlabel('Probability')
    ax2.set_title('Top K Class Probabilities')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Predict flower species from an image.')
    parser.add_argument('image_path', type=str, help='Path to the image file')
    parser.add_argument('checkpoint', type=str, help='Path to the checkpoint file')
    parser.add_argument('--top_k', type=int, default=5, help='Return top K classes')
    parser.add_argument('--category_names', type=str, default='cat_to_name.json', help='Path to the JSON file mapping categories to names')
    parser.add_argument('--arch', type=str, default='vgg16', help='Architecture: vgg16 or resnet50')
    parser.add_argument('--hidden_units', type=int, default=512, help='Number of hidden units in the classifier')
    
    args = parser.parse_args()

    model = load_checkpoint(args.checkpoint, args.arch, args.hidden_units)
    cat_to_name = load_cat_to_name(args.category_names)
    probs, classes = predict(args.image_path, model, args.top_k)

    print("Top K Probabilities: ", probs)
    print("Top K Classes: ", classes)

    display_prediction(args.image_path, model, cat_to_name, args.top_k)
